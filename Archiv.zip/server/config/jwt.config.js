const JWT_SECRET = process.env.JWT_SECRET || 'vase_super_tajne_heslo_123';  // Použijte silné heslo v produkci!

module.exports = {
    JWT_SECRET
}; 