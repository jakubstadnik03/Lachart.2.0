export const mockInvites = [
    {
      _id: "invite1",
      coachId: "user1",
      email: "new.athlete@example.com",
      status: "pending",
      createdAt: "2024-11-29T12:00:00Z",
      expiresAt: "2024-12-06T12:00:00Z",
    },
  ];
  